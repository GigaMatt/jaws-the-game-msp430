#ifndef sr_included
#define sr_included

void set_sr(int sr_val);
int  get_sr(void);
void or_sr (int or_val);
void and_sr(int and_val);

#endif
