#ifndef timerLib_included
#define timerLib_included

void configureClocks();
void enableWDTInterrupts();
void timerAUpmode();

#endif
