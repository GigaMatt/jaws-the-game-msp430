// State Machine from Dim demo

#ifndef stateMachine_included
#define stateMachine_included

void state_advance();
char toggle_red();
char toggle_green();
char toggle_red_green();


#endif // included
